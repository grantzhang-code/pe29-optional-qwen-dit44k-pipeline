"""MTP acceptance-rate evaluation."""
